﻿Imports System.Data
Imports System.Data.OleDb
Public Class Dashboard
    Dim con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\a\Documents\COLLAGE management\COLLAGE\CollageMNG.accdb")

    Private Sub countstud()
        Dim Stunum As Integer
        con.open()
        Dim oledb = "select count(*) from StudentTbl"
        Dim cmd As OleDbCommand
        cmd = New OleDbCommand(oledb, con)
        Stunum = cmd.ExecuteScalar
        StdLbl.Text = Stunum
        con.close()
    End Sub

    Private Sub countTeacher()
        Dim Tnum As Integer
        con.open()
        Dim oledb = "select count(*) from TeacherTbl"
        Dim cmd As OleDbCommand
        cmd = New OleDbCommand(oledb, con)
        Tnum = cmd.ExecuteScalar
        TeacherLbl.Text = Tnum
        con.close()
    End Sub
    Private Sub countDepartment()
        Dim Depnum As Integer
        con.open()
        Dim oledb = "select count(*) from DepartmentTbl"
        Dim cmd As OleDbCommand
        cmd = New OleDbCommand(oledb, con)
        Depnum = cmd.ExecuteScalar
        DepLbl.Text = Depnum
        con.close()
    End Sub
    Private Sub countFees()
        Dim Feesnum As Integer
        con.open()
        Dim oledb = "select count(*) from PaymentTbl"
        Dim cmd As OleDbCommand
        cmd = New OleDbCommand(oledb, con)
        Feesnum = cmd.ExecuteScalar
        FeesLbl.Text = Feesnum
        con.close()
    End Sub

    Private Sub Dashboard_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        countstud()
        countTeacher()
        countDepartment()
        countFees()

    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim obj = New Login()
        obj.Show()
        Me.Hide()

    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Dim obj = New Student()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim obj = New Teacher()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim obj = New Fees()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim obj = New Department()
        obj.Show()
        Me.Hide()
    End Sub
End Class