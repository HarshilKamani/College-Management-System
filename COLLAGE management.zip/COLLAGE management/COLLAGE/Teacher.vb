﻿Imports System.Data
Imports System.Data.OleDb
Public Class Teacher

    Dim con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\a\Documents\COLLAGE management\COLLAGE\CollageMNG.accdb")

    Private Sub FillDepartment()
        con.open()
        Dim query = "select * from DepartmentTbl"
        Dim cmd As New OleDbCommand(query, con)
        Dim adepter As New OleDbDataAdapter(cmd)
        Dim Tbl As New DataTable()
        adepter.Fill(Tbl)
        TDepCb.DataSource = Tbl
        TDepCb.DisplayMember = "DepName"
        TDepCb.ValueMember = "DepName"
        con.close()
    End Sub
    Private Sub Display()
        con.open()
        Dim query = "Select * from TeacherTbl"
        Dim adepter As OleDbDataAdapter
        Dim cmd = New OleDbCommand(query, con)
        adepter = New OleDbDataAdapter(cmd)
        Dim builder = New OleDbCommandBuilder(adepter)
        Dim ds As DataSet
        ds = New DataSet
        adepter.Fill(ds)
        TeacherDGV.DataSource = ds.Tables(0)
        con.close()
    End Sub
    Private Sub Clear()
        TNameTb.Text = ""
        TAddTb.Text = ""
        TCityTb.Text = ""
        TPincodeTb.Text = ""
        TPhoneTb.Text = ""
        TDOB.Text = ""
        TGenCb.SelectedIndex = 0
        TDepCb.SelectedIndex = 0

    End Sub
    Private Sub SaveBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        If TNameTb.Text = "" Or TAddTb.Text = "" Or TCityTb.Text = "" Or TPincodeTb.Text = "" Or TPhoneTb.Text = "" Or TGenCb.SelectedIndex.ToString = -1 Or TDepCb.SelectedIndex.ToString = -1 Then
            MsgBox("missing information")
        Else
            Try
                If con.State = ConnectionState.Closed Then
                    con.Open()
                End If

                Dim query = ("insert into TeacherTbl(TName,TGender,TDOB,TDep,TAdd,TCity,TPincode,Tphone) values('" & TNameTb.Text & "','" & TGenCb.SelectedItem.ToString() & "','" & TDOB.Value.Date & "','" & TDepCb.SelectedValue.ToString() & "','" & TAddTb.Text & "','" & TCityTb.Text & "','" & TPincodeTb.Text & "','" & TPhoneTb.Text & "')")
                Dim cmd As OleDbCommand
                cmd = New OleDbCommand(query, con)
                cmd.ExecuteNonQuery()
                MsgBox("Teacher Details Saved Successfully")
                con.Close()
                Display()
                Clear()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()

    End Sub

    Private Sub Teacher_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CollageMNGDataSet.TeacherTbl' table. You can move, or remove it, as needed.
        Me.TeacherTblTableAdapter.Fill(Me.CollageMNGDataSet.TeacherTbl)

        Display()
        FillDepartment()

    End Sub

    Private Sub ResetBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ResetBtn.Click
        Clear()

    End Sub

    Private Sub DeleteBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteBtn.Click
        If key = 0 Then
            MsgBox("Select The Teacher")
        Else
            Try
                con.open()
                Dim query = "delete from TeacherTbl where TId=" & key & ""
                Dim cmd As OleDbCommand
                cmd = New OleDbCommand(query, con)
                cmd.ExecuteNonQuery()
                MsgBox("Teacher Details Deleted successfull")
                con.close()
                Display()
                Clear()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub
    Dim key = 0
    Private Sub TeacherDGV_CellMouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles TeacherDGV.CellMouseClick
        Dim row As DataGridViewRow = TeacherDGV.Rows(e.RowIndex)
        TNameTb.Text = row.Cells(1).Value.ToString
        TGenCb.SelectedItem = row.Cells(2).Value.ToString
        TDOB.Text = row.Cells(3).Value.ToString
        TDepCb.SelectedValue = row.Cells(4).Value.ToString
        TAddTb.Text = row.Cells(5).Value.ToString
        TCityTb.Text = row.Cells(6).Value.ToString
        TPincodeTb.Text = row.Cells(7).Value.ToString
        TPhoneTb.Text = row.Cells(8).Value.ToString
        If TNameTb.Text = "" Then
            key = 0
        Else
            key = Convert.ToInt32(row.Cells(0).Value.ToString)
        End If
    End Sub

    Private Sub EditBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditBtn.Click
        If TNameTb.Text = "" Or TAddTb.Text = "" Or TCityTb.Text = "" Or TPincodeTb.Text = "" Or TPhoneTb.Text = "" Or TGenCb.SelectedIndex.ToString = -1 Or TDepCb.SelectedIndex.ToString = -1 Then
            MsgBox("missing information")
        Else
            Try
                con.Open()
                Dim query = "update TeacherTbl set TName='" & TNameTb.Text & "',TGender='" & TGenCb.SelectedItem.ToString() & "',TDOB='" & TDOB.Text & "' ,TDep='" & TDepCb.SelectedValue.ToString() & "' ,TAdd='" & TAddTb.Text & "' ,TCity='" & TCityTb.Text & "',TPincode='" & TPincodeTb.Text & "' ,TPhone='" & TPhoneTb.Text & "' where Tid=" & key & " "
                Dim cmd As OleDbCommand
                cmd = New OleDbCommand(query, con)
                cmd.ExecuteNonQuery()
                MsgBox("Teacher Update Successfully")
                con.Close()
                Display()
                Clear()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim obj = New Login()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim obj = New Dashboard()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim obj = New Fees()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim obj = New Department()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Dim obj = New Student()
        obj.Show()
        Me.Hide()
    End Sub
End Class