﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Teacher
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Teacher))
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TAddTb = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TGenCb = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TDOB = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TPhoneTb = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TNameTb = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TCityTb = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TDepCb = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TPincodeTb = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TeacherDGV = New System.Windows.Forms.DataGridView()
        Me.ResetBtn = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.DeleteBtn = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.EditBtn = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.SaveBtn = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.CollageMNGDataSet = New COLLAGE.CollageMNGDataSet()
        Me.TeacherTblBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TeacherTblTableAdapter = New COLLAGE.CollageMNGDataSetTableAdapters.TeacherTblTableAdapter()
        Me.Panel4.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.TeacherDGV, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CollageMNGDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TeacherTblBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.White
        Me.Panel4.Controls.Add(Me.Button2)
        Me.Panel4.Controls.Add(Me.Label17)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(344, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1598, 141)
        Me.Panel4.TabIndex = 41
        '
        'Button2
        '
        Me.Button2.BackgroundImage = Global.COLLAGE.My.Resources.Resources._1193
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button2.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace
        Me.Button2.FlatAppearance.BorderSize = 0
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Location = New System.Drawing.Point(1608, 6)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(49, 49)
        Me.Button2.TabIndex = 64
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.White
        Me.Label17.Font = New System.Drawing.Font("Century Gothic", 28.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Indigo
        Me.Label17.Location = New System.Drawing.Point(80, 69)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(234, 58)
        Me.Label17.TabIndex = 17
        Me.Label17.Text = "Teachers" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.SystemColors.Control
        Me.Label13.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Indigo
        Me.Label13.Location = New System.Drawing.Point(1179, 321)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(129, 34)
        Me.Label13.TabIndex = 63
        Me.Label13.Text = "Pincode"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Indigo
        Me.Label2.Location = New System.Drawing.Point(405, 321)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 34)
        Me.Label2.TabIndex = 39
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.SlateBlue
        Me.Panel2.Controls.Add(Me.PictureBox1)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Location = New System.Drawing.Point(-34, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(377, 141)
        Me.Panel2.TabIndex = 0
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.COLLAGE.My.Resources.Resources._4345672
        Me.PictureBox1.Location = New System.Drawing.Point(19, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(131, 141)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 16
        Me.PictureBox1.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.SlateBlue
        Me.Label6.Font = New System.Drawing.Font("Magneto", 19.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Gold
        Me.Label6.Location = New System.Drawing.Point(156, 33)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(201, 82)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "    HK" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Univercity" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Navy
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(108, 295)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(140, 37)
        Me.Label1.TabIndex = 65
        Me.Label1.Text = "Students"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Navy
        Me.Panel1.Controls.Add(Me.Button5)
        Me.Panel1.Controls.Add(Me.Button7)
        Me.Panel1.Controls.Add(Me.Button8)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Button6)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(344, 1102)
        Me.Panel1.TabIndex = 38
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.Navy
        Me.Button5.BackgroundImage = Global.COLLAGE.My.Resources.Resources.google_classroom
        Me.Button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button5.FlatAppearance.BorderSize = 0
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Location = New System.Drawing.Point(109, 366)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(129, 113)
        Me.Button5.TabIndex = 64
        Me.Button5.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.Navy
        Me.Button7.BackgroundImage = Global.COLLAGE.My.Resources.Resources._1035688
        Me.Button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button7.FlatAppearance.BorderSize = 0
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.Location = New System.Drawing.Point(95, 781)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(156, 113)
        Me.Button7.TabIndex = 45
        Me.Button7.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.Navy
        Me.Button8.BackgroundImage = Global.COLLAGE.My.Resources.Resources._3523407
        Me.Button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button8.FlatAppearance.BorderSize = 0
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Location = New System.Drawing.Point(97, 176)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(156, 113)
        Me.Button8.TabIndex = 66
        Me.Button8.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Navy
        Me.Button6.BackgroundImage = Global.COLLAGE.My.Resources.Resources._3141981
        Me.Button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button6.FlatAppearance.BorderSize = 0
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Location = New System.Drawing.Point(95, 578)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(156, 113)
        Me.Button6.TabIndex = 44
        Me.Button6.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackgroundImage = Global.COLLAGE.My.Resources.Resources._152535
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button3.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace
        Me.Button3.FlatAppearance.BorderSize = 0
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Location = New System.Drawing.Point(91, 975)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(133, 62)
        Me.Button3.TabIndex = 38
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Navy
        Me.Label16.Font = New System.Drawing.Font("Century Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(133, 694)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(82, 37)
        Me.Label16.TabIndex = 20
        Me.Label16.Text = "Fees"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Navy
        Me.Label15.Font = New System.Drawing.Font("Century Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(81, 897)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(179, 37)
        Me.Label15.TabIndex = 19
        Me.Label15.Text = "Dashboard"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Navy
        Me.Label14.Font = New System.Drawing.Font("Century Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(76, 482)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(192, 37)
        Me.Label14.TabIndex = 18
        Me.Label14.Text = "Department"
        '
        'TAddTb
        '
        Me.TAddTb.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TeacherTblBindingSource, "TAdd", True))
        Me.TAddTb.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TAddTb.Location = New System.Drawing.Point(387, 376)
        Me.TAddTb.Name = "TAddTb"
        Me.TAddTb.Size = New System.Drawing.Size(325, 36)
        Me.TAddTb.TabIndex = 40
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Indigo
        Me.Label3.Location = New System.Drawing.Point(786, 176)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(119, 34)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "Gender"
        '
        'TGenCb
        '
        Me.TGenCb.DataBindings.Add(New System.Windows.Forms.Binding("SelectedItem", Me.TeacherTblBindingSource, "TGender", True))
        Me.TGenCb.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TGenCb.FormattingEnabled = True
        Me.TGenCb.Items.AddRange(New Object() {"Male", "Female"})
        Me.TGenCb.Location = New System.Drawing.Point(795, 226)
        Me.TGenCb.Name = "TGenCb"
        Me.TGenCb.Size = New System.Drawing.Size(290, 35)
        Me.TGenCb.TabIndex = 44
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Indigo
        Me.Label4.Location = New System.Drawing.Point(1179, 176)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 34)
        Me.Label4.TabIndex = 45
        Me.Label4.Text = "DOB"
        '
        'TDOB
        '
        Me.TDOB.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TeacherTblBindingSource, "TDOB", True))
        Me.TDOB.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TDOB.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.TDOB.Location = New System.Drawing.Point(1188, 226)
        Me.TDOB.Name = "TDOB"
        Me.TDOB.Size = New System.Drawing.Size(329, 36)
        Me.TDOB.TabIndex = 46
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Indigo
        Me.Label5.Location = New System.Drawing.Point(1604, 321)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(152, 34)
        Me.Label5.TabIndex = 47
        Me.Label5.Text = "Phone no."
        '
        'TPhoneTb
        '
        Me.TPhoneTb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TPhoneTb.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TeacherTblBindingSource, "TPhone", True))
        Me.TPhoneTb.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TPhoneTb.Location = New System.Drawing.Point(1613, 376)
        Me.TPhoneTb.Name = "TPhoneTb"
        Me.TPhoneTb.Size = New System.Drawing.Size(329, 36)
        Me.TPhoneTb.TabIndex = 48
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Indigo
        Me.Label7.Location = New System.Drawing.Point(378, 176)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(99, 34)
        Me.Label7.TabIndex = 49
        Me.Label7.Text = "Name"
        '
        'TNameTb
        '
        Me.TNameTb.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TeacherTblBindingSource, "TName", True))
        Me.TNameTb.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TNameTb.Location = New System.Drawing.Point(383, 225)
        Me.TNameTb.Name = "TNameTb"
        Me.TNameTb.Size = New System.Drawing.Size(329, 36)
        Me.TNameTb.TabIndex = 50
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label8.Location = New System.Drawing.Point(1093, 740)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(0, 34)
        Me.Label8.TabIndex = 51
        '
        'TCityTb
        '
        Me.TCityTb.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TeacherTblBindingSource, "TCity", True))
        Me.TCityTb.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TCityTb.Location = New System.Drawing.Point(795, 376)
        Me.TCityTb.Name = "TCityTb"
        Me.TCityTb.Size = New System.Drawing.Size(290, 36)
        Me.TCityTb.TabIndex = 52
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.SystemColors.Control
        Me.Label9.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Indigo
        Me.Label9.Location = New System.Drawing.Point(1598, 176)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(181, 34)
        Me.Label9.TabIndex = 53
        Me.Label9.Text = "Department"
        '
        'TDepCb
        '
        Me.TDepCb.DataBindings.Add(New System.Windows.Forms.Binding("SelectedItem", Me.TeacherTblBindingSource, "TDep", True))
        Me.TDepCb.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TDepCb.FormattingEnabled = True
        Me.TDepCb.Items.AddRange(New Object() {""})
        Me.TDepCb.Location = New System.Drawing.Point(1607, 226)
        Me.TDepCb.Name = "TDepCb"
        Me.TDepCb.Size = New System.Drawing.Size(335, 35)
        Me.TDepCb.TabIndex = 54
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.SystemColors.Control
        Me.Label10.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Indigo
        Me.Label10.Location = New System.Drawing.Point(378, 326)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(122, 34)
        Me.Label10.TabIndex = 55
        Me.Label10.Text = "Address"
        '
        'TPincodeTb
        '
        Me.TPincodeTb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TPincodeTb.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TeacherTblBindingSource, "TPincode", True))
        Me.TPincodeTb.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TPincodeTb.Location = New System.Drawing.Point(1188, 376)
        Me.TPincodeTb.Name = "TPincodeTb"
        Me.TPincodeTb.Size = New System.Drawing.Size(329, 36)
        Me.TPincodeTb.TabIndex = 56
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.SystemColors.Control
        Me.Label11.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Indigo
        Me.Label11.Location = New System.Drawing.Point(786, 321)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(70, 34)
        Me.Label11.TabIndex = 57
        Me.Label11.Text = "City"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.SystemColors.Control
        Me.Label12.Font = New System.Drawing.Font("Century Gothic", 22.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Indigo
        Me.Label12.Location = New System.Drawing.Point(1038, 552)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(238, 45)
        Me.Label12.TabIndex = 43
        Me.Label12.Text = "Teacher List"
        '
        'TeacherDGV
        '
        Me.TeacherDGV.AllowUserToAddRows = False
        Me.TeacherDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.TeacherDGV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.TeacherDGV.BackgroundColor = System.Drawing.Color.White
        Me.TeacherDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        Me.TeacherDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.Navy
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Navy
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Lavender
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.TeacherDGV.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.TeacherDGV.ColumnHeadersHeight = 28
        Me.TeacherDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.TeacherDGV.Cursor = System.Windows.Forms.Cursors.Default
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.Gold
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.DarkBlue
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.TeacherDGV.DefaultCellStyle = DataGridViewCellStyle8
        Me.TeacherDGV.EnableHeadersVisualStyles = False
        Me.TeacherDGV.GridColor = System.Drawing.Color.White
        Me.TeacherDGV.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.TeacherDGV.Location = New System.Drawing.Point(383, 624)
        Me.TeacherDGV.Name = "TeacherDGV"
        Me.TeacherDGV.ReadOnly = True
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Century Gothic", 14.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.Gold
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.DarkBlue
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.TeacherDGV.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.TeacherDGV.RowHeadersWidth = 51
        Me.TeacherDGV.RowTemplate.Height = 24
        Me.TeacherDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.TeacherDGV.Size = New System.Drawing.Size(1621, 413)
        Me.TeacherDGV.TabIndex = 86
        '
        'ResetBtn
        '
        Me.ResetBtn.ActiveBorderThickness = 1
        Me.ResetBtn.ActiveCornerRadius = 20
        Me.ResetBtn.ActiveFillColor = System.Drawing.Color.SeaGreen
        Me.ResetBtn.ActiveForecolor = System.Drawing.Color.White
        Me.ResetBtn.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.ResetBtn.BackColor = System.Drawing.SystemColors.Control
        Me.ResetBtn.BackgroundImage = CType(resources.GetObject("ResetBtn.BackgroundImage"), System.Drawing.Image)
        Me.ResetBtn.ButtonText = "Reset"
        Me.ResetBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ResetBtn.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ResetBtn.ForeColor = System.Drawing.Color.SeaGreen
        Me.ResetBtn.IdleBorderThickness = 1
        Me.ResetBtn.IdleCornerRadius = 20
        Me.ResetBtn.IdleFillColor = System.Drawing.Color.Gold
        Me.ResetBtn.IdleForecolor = System.Drawing.Color.Black
        Me.ResetBtn.IdleLineColor = System.Drawing.Color.Gold
        Me.ResetBtn.Location = New System.Drawing.Point(1613, 464)
        Me.ResetBtn.Margin = New System.Windows.Forms.Padding(7, 7, 7, 7)
        Me.ResetBtn.Name = "ResetBtn"
        Me.ResetBtn.Size = New System.Drawing.Size(327, 52)
        Me.ResetBtn.TabIndex = 62
        Me.ResetBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'DeleteBtn
        '
        Me.DeleteBtn.ActiveBorderThickness = 1
        Me.DeleteBtn.ActiveCornerRadius = 20
        Me.DeleteBtn.ActiveFillColor = System.Drawing.Color.SeaGreen
        Me.DeleteBtn.ActiveForecolor = System.Drawing.Color.White
        Me.DeleteBtn.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.DeleteBtn.BackColor = System.Drawing.SystemColors.Control
        Me.DeleteBtn.BackgroundImage = CType(resources.GetObject("DeleteBtn.BackgroundImage"), System.Drawing.Image)
        Me.DeleteBtn.ButtonText = "Delete"
        Me.DeleteBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.DeleteBtn.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeleteBtn.ForeColor = System.Drawing.Color.SeaGreen
        Me.DeleteBtn.IdleBorderThickness = 1
        Me.DeleteBtn.IdleCornerRadius = 20
        Me.DeleteBtn.IdleFillColor = System.Drawing.Color.Gold
        Me.DeleteBtn.IdleForecolor = System.Drawing.Color.Black
        Me.DeleteBtn.IdleLineColor = System.Drawing.Color.Gold
        Me.DeleteBtn.Location = New System.Drawing.Point(1188, 464)
        Me.DeleteBtn.Margin = New System.Windows.Forms.Padding(7, 7, 7, 7)
        Me.DeleteBtn.Name = "DeleteBtn"
        Me.DeleteBtn.Size = New System.Drawing.Size(329, 52)
        Me.DeleteBtn.TabIndex = 61
        Me.DeleteBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'EditBtn
        '
        Me.EditBtn.ActiveBorderThickness = 1
        Me.EditBtn.ActiveCornerRadius = 20
        Me.EditBtn.ActiveFillColor = System.Drawing.Color.SeaGreen
        Me.EditBtn.ActiveForecolor = System.Drawing.Color.White
        Me.EditBtn.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.EditBtn.BackColor = System.Drawing.SystemColors.Control
        Me.EditBtn.BackgroundImage = CType(resources.GetObject("EditBtn.BackgroundImage"), System.Drawing.Image)
        Me.EditBtn.ButtonText = "Edit"
        Me.EditBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.EditBtn.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EditBtn.ForeColor = System.Drawing.Color.SeaGreen
        Me.EditBtn.IdleBorderThickness = 1
        Me.EditBtn.IdleCornerRadius = 20
        Me.EditBtn.IdleFillColor = System.Drawing.Color.Gold
        Me.EditBtn.IdleForecolor = System.Drawing.Color.Black
        Me.EditBtn.IdleLineColor = System.Drawing.Color.Gold
        Me.EditBtn.Location = New System.Drawing.Point(792, 464)
        Me.EditBtn.Margin = New System.Windows.Forms.Padding(7, 7, 7, 7)
        Me.EditBtn.Name = "EditBtn"
        Me.EditBtn.Size = New System.Drawing.Size(293, 52)
        Me.EditBtn.TabIndex = 60
        Me.EditBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SaveBtn
        '
        Me.SaveBtn.ActiveBorderThickness = 1
        Me.SaveBtn.ActiveCornerRadius = 20
        Me.SaveBtn.ActiveFillColor = System.Drawing.Color.SeaGreen
        Me.SaveBtn.ActiveForecolor = System.Drawing.Color.White
        Me.SaveBtn.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.SaveBtn.BackColor = System.Drawing.SystemColors.Control
        Me.SaveBtn.BackgroundImage = CType(resources.GetObject("SaveBtn.BackgroundImage"), System.Drawing.Image)
        Me.SaveBtn.ButtonText = "Save"
        Me.SaveBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.SaveBtn.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SaveBtn.ForeColor = System.Drawing.Color.SeaGreen
        Me.SaveBtn.IdleBorderThickness = 1
        Me.SaveBtn.IdleCornerRadius = 20
        Me.SaveBtn.IdleFillColor = System.Drawing.Color.Gold
        Me.SaveBtn.IdleForecolor = System.Drawing.Color.Black
        Me.SaveBtn.IdleLineColor = System.Drawing.Color.Gold
        Me.SaveBtn.Location = New System.Drawing.Point(385, 464)
        Me.SaveBtn.Margin = New System.Windows.Forms.Padding(7, 7, 7, 7)
        Me.SaveBtn.Name = "SaveBtn"
        Me.SaveBtn.Size = New System.Drawing.Size(327, 52)
        Me.SaveBtn.TabIndex = 59
        Me.SaveBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CollageMNGDataSet
        '
        Me.CollageMNGDataSet.DataSetName = "CollageMNGDataSet"
        Me.CollageMNGDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TeacherTblBindingSource
        '
        Me.TeacherTblBindingSource.DataMember = "TeacherTbl"
        Me.TeacherTblBindingSource.DataSource = Me.CollageMNGDataSet
        '
        'TeacherTblTableAdapter
        '
        Me.TeacherTblTableAdapter.ClearBeforeFill = True
        '
        'Teacher
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1942, 1102)
        Me.Controls.Add(Me.TeacherDGV)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.ResetBtn)
        Me.Controls.Add(Me.DeleteBtn)
        Me.Controls.Add(Me.EditBtn)
        Me.Controls.Add(Me.SaveBtn)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.TPincodeTb)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.TDepCb)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TCityTb)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TNameTb)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TPhoneTb)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TDOB)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TGenCb)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.TAddTb)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Teacher"
        Me.Text = "Teachers"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.TeacherDGV, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CollageMNGDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TeacherTblBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents SaveBtn As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents EditBtn As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents DeleteBtn As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents ResetBtn As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TAddTb As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TGenCb As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TDOB As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TPhoneTb As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TNameTb As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TCityTb As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TDepCb As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TPincodeTb As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TeacherDGV As System.Windows.Forms.DataGridView
    Friend WithEvents CollageMNGDataSet As CollageMNGDataSet
    Friend WithEvents TeacherTblBindingSource As BindingSource
    Friend WithEvents TeacherTblTableAdapter As CollageMNGDataSetTableAdapters.TeacherTblTableAdapter
End Class
