﻿Imports System.Data
Imports System.Data.OleDb

Public Class Fees
    Dim con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\a\Documents\COLLAGE management\COLLAGE\CollageMNG.accdb")
    Private Sub FillStudent()
        con.open()
        Dim query = "select * from StudentTbl"
        Dim cmd As New OleDbCommand(query, con)
        Dim adepter As New OleDbDataAdapter(cmd)
        Dim dt As New DataTable()
        adepter.Fill(dt)
        StuIDCb.DataSource = dt
        StuIDCb.DisplayMember = "StuId"
        StuIDCb.ValueMember = "StuId"
        con.close()
    End Sub
    Private Sub Display()
        con.open()
        Dim query = "Select * from PaymentTbl"
        Dim adepter As OleDbDataAdapter
        Dim cmd = New OleDbCommand(query, con)
        adepter = New OleDbDataAdapter(cmd)
        Dim builder = New OleDbCommandBuilder(adepter)
        Dim ds As DataSet
        ds = New DataSet
        adepter.Fill(ds)
        FeesDGV.DataSource = ds.Tables(0)
        con.close()
    End Sub
    Private Sub Clear()
        AmountTb.Text = ""
        SNameTb.Text = ""
        StuIDCb.SelectedIndex = -1

    End Sub
   


    Private Sub PayBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PayBtn.Click
        If SNameTb.Text = "" Or AmountTb.Text = "" Then
            MsgBox("missing information")
        ElseIf Convert.ToInt32(AmountTb.Text) > 100000 Or Convert.ToInt32(AmountTb.Text) < 1 Then
            MsgBox("wrong Ammount")
        Else
            Try
                If con.State = ConnectionState.Closed Then
                    con.Open()
                End If
                Dim query = ("insert into PaymentTbl (StuId,StuName,Period,Amount) values ('" & StuIDCb.SelectedValue.ToString() & "','" & SNameTb.Text & "','" & PeriodDTP.Value.Date & "','" & AmountTb.Text & "')")
                Dim cmd As OleDbCommand
                cmd = New OleDbCommand(query, con)
                cmd.ExecuteNonQuery()
                MsgBox("Payment Details Saved Successfully")
                con.Close()
                Display()
                Clear()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()

    End Sub
    Private Sub GetStuName()
        con.open()
        Dim Query = "Select * From StudentTbl Where StuId=" & StuIDCb.SelectedValue.ToString() & ""
        Dim cmd As New OleDbCommand(Query, con)
        Dim dt As New DataTable
        Dim reader As OleDbDataReader
        reader = cmd.ExecuteReader()
        While reader.Read
            SNameTb.Text = reader(1).ToString
        End While
        con.close()

    End Sub
    Private Sub Fees_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CollageMNGDataSet.PaymentTbl' table. You can move, or remove it, as needed.
        Me.PaymentTblTableAdapter.Fill(Me.CollageMNGDataSet.PaymentTbl)

        FillStudent()
        Display()
    End Sub

    Private Sub StuIDCb_SelectionChangeCommitted(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StuIDCb.SelectionChangeCommitted
        GetStuName()

    End Sub


    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim obj = New Login()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim obj = New Dashboard()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim obj = New Teacher()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Dim obj = New Student()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim obj = New Department()
        obj.Show()
        Me.Hide()
    End Sub
End Class