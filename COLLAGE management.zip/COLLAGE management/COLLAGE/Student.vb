﻿Imports System.Data
Imports System.Data.OleDb

Public Class Student
    Dim con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\a\Documents\COLLAGE management\COLLAGE\CollageMNG.accdb")


    Private Sub FillDepartment()
        con.open()
        Dim query = "select * from DepartmentTbl"
        Dim cmd As New OleDbCommand(query, con)
        Dim adepter As New OleDbDataAdapter(cmd)
        Dim Tbl As New DataTable()
        adepter.Fill(Tbl)
        StuDeptCb.DataSource = Tbl
        StuDeptCb.DisplayMember = "DepName"
        StuDeptCb.ValueMember = "DepName"
        con.close()
    End Sub
    Private Sub Display()
        con.open()
        Dim query = "Select * from StudentTbl"
        Dim adepter As OleDbDataAdapter
        Dim cmd = New OleDbCommand(query, con)
        adepter = New OleDbDataAdapter(cmd)
        Dim builder = New OleDbCommandBuilder(adepter)
        Dim ds As DataSet
        ds = New DataSet
        adepter.Fill(ds)
        StudentDGV.DataSource = ds.Tables(0)
        con.close()
    End Sub
    Private Sub NoDueList()
        con.open()
        Dim query = "Select * from StudentTbl Where StuFees >= 100000"
        Dim adepter As OleDbDataAdapter
        Dim cmd = New OleDbCommand(query, con)
        adepter = New OleDbDataAdapter(cmd)
        Dim builder = New OleDbCommandBuilder(adepter)
        Dim ds As DataSet
        ds = New DataSet
        adepter.Fill(ds)
        StudentDGV.DataSource = ds.Tables(0)
        con.close()
    End Sub
    Private Sub Clear()
        StuNameTb.Text = ""
        StuFeesTb.Text = ""
        StuAddTb.Text = ""
        StuCityTb.Text = ""
        StuPhoneTb.Text = ""
        StuDobDTP.Text = ""
        StuGenderCb.SelectedIndex = 0
        StuDeptCb.SelectedIndex = 0

    End Sub
    Private Sub SaveBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        If StuNameTb.Text = "" Or StuFeesTb.Text = "" Or StuAddTb.Text = "" Or StuCityTb.Text = "" Or StuPhoneTb.Text = "" Or StuGenderCb.SelectedIndex.ToString = -1 Or StuDeptCb.SelectedIndex.ToString = -1 Then
            MsgBox("missing information")
        Else
            Try
                If con.State = ConnectionState.Closed Then
                    con.Open()
                End If

                Dim query = ("insert into StudentTbl(StuName,StuGender,StuDob,StuDept,StuFees,StuAdd,Stucity,StuPhone) values ('" & StuNameTb.Text & "','" & StuGenderCb.SelectedItem.ToString() & "','" & StuDobDTP.Value.Date & "','" & StuDeptCb.SelectedValue.ToString() & "','" & StuFeesTb.Text & "','" & StuAddTb.Text & "','" & StuCityTb.Text & "','" & StuPhoneTb.Text & "')")
                Dim cmd As OleDbCommand
                cmd = New OleDbCommand(query, con)
                cmd.ExecuteNonQuery()
                MsgBox("Student Details Saved Successfully")
                con.Close()
                Display()
                Clear()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
        
    End Sub
   
    Private Sub Student_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CollageMNGDataSet.StudentTbl' table. You can move, or remove it, as needed.
        Me.StudentTblTableAdapter.Fill(Me.CollageMNGDataSet.StudentTbl)
        FillDepartment()
        Display()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Me.Close()

    End Sub

    Private Sub ResetBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ResetBtn.Click
        Clear()
    End Sub
    Dim key = 0

    Private Sub StudentDGV_CellMouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles StudentDGV.CellMouseClick
        Dim row As DataGridViewRow = StudentDGV.Rows(e.RowIndex)
        StuNameTb.Text = row.Cells(1).Value.ToString
        StuGenderCb.SelectedItem = row.Cells(2).Value.ToString
        StuDobDTP.Text = row.Cells(3).Value.ToString
        StuDeptCb.SelectedValue = row.Cells(4).Value.ToString
        StuAddTb.Text = row.Cells(5).Value.ToString
        StuCityTb.Text = row.Cells(6).Value.ToString
        StuFeesTb.Text = row.Cells(7).Value.ToString
        StuPhoneTb.Text = row.Cells(8).Value.ToString
        If StuNameTb.Text = "" Then
            key = 0
        Else
            key = Convert.ToInt32(row.Cells(0).Value.ToString)
        End If
    End Sub

    Private Sub DeleteBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteBtn.Click
        If key = 0 Then
            MsgBox("Select The Student")
        Else
            Try
                con.open()
                Dim query = "delete from StudentTbl where StuId=" & key & ""
                Dim cmd As OleDbCommand
                cmd = New OleDbCommand(query, con)
                cmd.ExecuteNonQuery()
                MsgBox("Student Deleted successfull")
                con.close()
                Display()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub EditBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditBtn.Click
        If StuNameTb.Text = "" Or StuFeesTb.Text = "" Or StuAddTb.Text = "" Or StuCityTb.Text = "" Or StuPhoneTb.Text = "" Or StuGenderCb.SelectedIndex.ToString = -1 Or StuDeptCb.SelectedIndex.ToString = -1 Then
            MsgBox("missing information")
        Else
            Try
                con.Open()
                Dim query = "update StudentTbl set StuName='" & StuNameTb.Text & "',StuGender='" & StuGenderCb.SelectedItem.ToString() & "',StuDob='" & StuDobDTP.Text & "' ,StuDept='" & StuDeptCb.SelectedValue.ToString() & "' ,StuAdd='" & StuAddTb.Text & "' ,StuCity='" & StuCityTb.Text & "',StuFees='" & StuFeesTb.Text & "' ,StuPhone='" & StuPhoneTb.Text & "' where StuId=" & key & " "
                Dim cmd As OleDbCommand
                cmd = New OleDbCommand(query, con)
                cmd.ExecuteNonQuery()
                MsgBox("Student Update Successfully")
                con.Close()
                Display()
                Clear()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    
   
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim obj = New Login()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim obj = New Dashboard()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim obj = New Fees()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim obj = New Department()
        obj.Show()
        Me.Hide()
    End Sub

   
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim obj = New Teacher()
        obj.Show()
        Me.Hide()
    End Sub
End Class