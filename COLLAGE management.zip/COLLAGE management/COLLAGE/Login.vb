﻿Public Class Login

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()

    End Sub

    Private Sub Label5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label5.Click
        UNameTb.Text = ""
        PassTb.Text = ""

    End Sub

    
    Private Sub LoginBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoginBtn.Click
        If UNameTb.Text = "" Or PassTb.Text = "" Then
            MsgBox("Enter UserName And Password")
        ElseIf UNameTb.Text = "Admin" And PassTb.Text = "Admin123" Then
            Dim obj = New Dashboard
            obj.Show()
            Me.Hide()
        Else
            MsgBox("Wrong UserName Or password")
            UNameTb.Text = ""
            PassTb.Text = ""
        End If
    End Sub
End Class