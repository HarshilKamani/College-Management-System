﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Fees
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Fees))
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SNameTb = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PeriodDTP = New System.Windows.Forms.DateTimePicker()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.AmountTb = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.FeesDGV = New System.Windows.Forms.DataGridView()
        Me.StuIDCb = New System.Windows.Forms.ComboBox()
        Me.PayBtn = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.CollageMNGDataSet = New COLLAGE.CollageMNGDataSet()
        Me.PaymentTblBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PaymentTblTableAdapter = New COLLAGE.CollageMNGDataSetTableAdapters.PaymentTblTableAdapter()
        Me.Panel4.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.FeesDGV, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CollageMNGDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PaymentTblBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.White
        Me.Panel4.Controls.Add(Me.Button2)
        Me.Panel4.Controls.Add(Me.Label1)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(344, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1598, 141)
        Me.Panel4.TabIndex = 41
        '
        'Button2
        '
        Me.Button2.BackgroundImage = Global.COLLAGE.My.Resources.Resources._1193
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button2.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace
        Me.Button2.FlatAppearance.BorderSize = 0
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Location = New System.Drawing.Point(1572, 5)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(50, 49)
        Me.Button2.TabIndex = 63
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 28.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Indigo
        Me.Label1.Location = New System.Drawing.Point(85, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(226, 58)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Account"
        '
        'SNameTb
        '
        Me.SNameTb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.SNameTb.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PaymentTblBindingSource, "StuName", True))
        Me.SNameTb.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SNameTb.Location = New System.Drawing.Point(817, 269)
        Me.SNameTb.Name = "SNameTb"
        Me.SNameTb.ReadOnly = True
        Me.SNameTb.Size = New System.Drawing.Size(307, 36)
        Me.SNameTb.TabIndex = 56
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.SystemColors.Control
        Me.Label12.Font = New System.Drawing.Font("Century Gothic", 22.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Indigo
        Me.Label12.Location = New System.Drawing.Point(1050, 477)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(255, 45)
        Me.Label12.TabIndex = 43
        Me.Label12.Text = "Payment List"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Indigo
        Me.Label3.Location = New System.Drawing.Point(813, 220)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(99, 34)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Indigo
        Me.Label4.Location = New System.Drawing.Point(1206, 220)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(102, 34)
        Me.Label4.TabIndex = 45
        Me.Label4.Text = "Period"
        '
        'PeriodDTP
        '
        Me.PeriodDTP.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.PaymentTblBindingSource, "Period", True))
        Me.PeriodDTP.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PeriodDTP.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.PeriodDTP.Location = New System.Drawing.Point(1210, 270)
        Me.PeriodDTP.Name = "PeriodDTP"
        Me.PeriodDTP.Size = New System.Drawing.Size(307, 36)
        Me.PeriodDTP.TabIndex = 46
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Indigo
        Me.Label7.Location = New System.Drawing.Point(401, 220)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(155, 34)
        Me.Label7.TabIndex = 49
        Me.Label7.Text = "Student ID"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label8.Location = New System.Drawing.Point(1093, 740)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(0, 34)
        Me.Label8.TabIndex = 51
        '
        'AmountTb
        '
        Me.AmountTb.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PaymentTblBindingSource, "Amount", True))
        Me.AmountTb.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AmountTb.Location = New System.Drawing.Point(1607, 269)
        Me.AmountTb.Name = "AmountTb"
        Me.AmountTb.Size = New System.Drawing.Size(268, 36)
        Me.AmountTb.TabIndex = 52
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.SystemColors.Control
        Me.Label10.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Indigo
        Me.Label10.Location = New System.Drawing.Point(1603, 219)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(124, 34)
        Me.Label10.TabIndex = 55
        Me.Label10.Text = "Amount"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.SlateBlue
        Me.Panel2.Controls.Add(Me.PictureBox1)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(343, 141)
        Me.Panel2.TabIndex = 0
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.COLLAGE.My.Resources.Resources._4345672
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(125, 138)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 16
        Me.PictureBox1.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.SlateBlue
        Me.Label6.Font = New System.Drawing.Font("Magneto", 19.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Gold
        Me.Label6.Location = New System.Drawing.Point(122, 25)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(201, 82)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "    HK" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Univercity" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Panel3
        '
        Me.Panel3.Location = New System.Drawing.Point(347, 5)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(202, 100)
        Me.Panel3.TabIndex = 15
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Navy
        Me.Label13.Font = New System.Drawing.Font("Century Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(101, 285)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(146, 37)
        Me.Label13.TabIndex = 17
        Me.Label13.Text = "Teachers"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Navy
        Me.Label14.Font = New System.Drawing.Font("Century Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(76, 482)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(192, 37)
        Me.Label14.TabIndex = 18
        Me.Label14.Text = "Department"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Navy
        Me.Label15.Font = New System.Drawing.Font("Century Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(88, 896)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(179, 37)
        Me.Label15.TabIndex = 19
        Me.Label15.Text = "Dashboard"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Navy
        Me.Panel1.Controls.Add(Me.Button8)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Button5)
        Me.Panel1.Controls.Add(Me.Button7)
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(344, 1102)
        Me.Panel1.TabIndex = 38
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.Navy
        Me.Button8.BackgroundImage = Global.COLLAGE.My.Resources.Resources._3523407
        Me.Button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button8.FlatAppearance.BorderSize = 0
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Location = New System.Drawing.Point(58, 566)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(226, 113)
        Me.Button8.TabIndex = 68
        Me.Button8.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Navy
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(110, 685)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(128, 37)
        Me.Label2.TabIndex = 67
        Me.Label2.Text = "Student"
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.Navy
        Me.Button5.BackgroundImage = Global.COLLAGE.My.Resources.Resources.google_classroom
        Me.Button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button5.FlatAppearance.BorderSize = 0
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Location = New System.Drawing.Point(106, 355)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(134, 113)
        Me.Button5.TabIndex = 46
        Me.Button5.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.Navy
        Me.Button7.BackgroundImage = Global.COLLAGE.My.Resources.Resources._1035688
        Me.Button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button7.FlatAppearance.BorderSize = 0
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.Location = New System.Drawing.Point(110, 776)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(134, 113)
        Me.Button7.TabIndex = 45
        Me.Button7.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Navy
        Me.Button4.BackgroundImage = Global.COLLAGE.My.Resources.Resources._2133094
        Me.Button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button4.FlatAppearance.BorderSize = 0
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Location = New System.Drawing.Point(104, 166)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(134, 113)
        Me.Button4.TabIndex = 42
        Me.Button4.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackgroundImage = Global.COLLAGE.My.Resources.Resources._152535
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button3.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace
        Me.Button3.FlatAppearance.BorderSize = 0
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Location = New System.Drawing.Point(113, 975)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(111, 62)
        Me.Button3.TabIndex = 38
        Me.Button3.UseVisualStyleBackColor = True
        '
        'FeesDGV
        '
        Me.FeesDGV.AllowUserToAddRows = False
        Me.FeesDGV.AllowUserToOrderColumns = True
        Me.FeesDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.FeesDGV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.FeesDGV.BackgroundColor = System.Drawing.Color.White
        Me.FeesDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        Me.FeesDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.Navy
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Navy
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Lavender
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.FeesDGV.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.FeesDGV.ColumnHeadersHeight = 28
        Me.FeesDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.FeesDGV.Cursor = System.Windows.Forms.Cursors.Default
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.Gold
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.DarkBlue
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.FeesDGV.DefaultCellStyle = DataGridViewCellStyle8
        Me.FeesDGV.EnableHeadersVisualStyles = False
        Me.FeesDGV.GridColor = System.Drawing.Color.White
        Me.FeesDGV.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.FeesDGV.Location = New System.Drawing.Point(515, 562)
        Me.FeesDGV.Name = "FeesDGV"
        Me.FeesDGV.ReadOnly = True
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Century Gothic", 14.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.Gold
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.DarkBlue
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.FeesDGV.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.FeesDGV.RowHeadersWidth = 51
        Me.FeesDGV.RowTemplate.Height = 24
        Me.FeesDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.FeesDGV.Size = New System.Drawing.Size(1385, 466)
        Me.FeesDGV.TabIndex = 85
        '
        'StuIDCb
        '
        Me.StuIDCb.DataBindings.Add(New System.Windows.Forms.Binding("SelectedItem", Me.PaymentTblBindingSource, "StuId", True))
        Me.StuIDCb.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StuIDCb.FormattingEnabled = True
        Me.StuIDCb.Items.AddRange(New Object() {"FEMALE", "MALE"})
        Me.StuIDCb.Location = New System.Drawing.Point(407, 268)
        Me.StuIDCb.Name = "StuIDCb"
        Me.StuIDCb.Size = New System.Drawing.Size(266, 35)
        Me.StuIDCb.Sorted = True
        Me.StuIDCb.TabIndex = 63
        '
        'PayBtn
        '
        Me.PayBtn.ActiveBorderThickness = 1
        Me.PayBtn.ActiveCornerRadius = 20
        Me.PayBtn.ActiveFillColor = System.Drawing.Color.SeaGreen
        Me.PayBtn.ActiveForecolor = System.Drawing.Color.White
        Me.PayBtn.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.PayBtn.BackColor = System.Drawing.SystemColors.Control
        Me.PayBtn.BackgroundImage = CType(resources.GetObject("PayBtn.BackgroundImage"), System.Drawing.Image)
        Me.PayBtn.ButtonText = "Pay"
        Me.PayBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PayBtn.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PayBtn.ForeColor = System.Drawing.Color.SeaGreen
        Me.PayBtn.IdleBorderThickness = 1
        Me.PayBtn.IdleCornerRadius = 20
        Me.PayBtn.IdleFillColor = System.Drawing.Color.Gold
        Me.PayBtn.IdleForecolor = System.Drawing.Color.Black
        Me.PayBtn.IdleLineColor = System.Drawing.Color.Gold
        Me.PayBtn.Location = New System.Drawing.Point(984, 387)
        Me.PayBtn.Margin = New System.Windows.Forms.Padding(7, 7, 7, 7)
        Me.PayBtn.Name = "PayBtn"
        Me.PayBtn.Size = New System.Drawing.Size(324, 53)
        Me.PayBtn.TabIndex = 61
        Me.PayBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CollageMNGDataSet
        '
        Me.CollageMNGDataSet.DataSetName = "CollageMNGDataSet"
        Me.CollageMNGDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PaymentTblBindingSource
        '
        Me.PaymentTblBindingSource.DataMember = "PaymentTbl"
        Me.PaymentTblBindingSource.DataSource = Me.CollageMNGDataSet
        '
        'PaymentTblTableAdapter
        '
        Me.PaymentTblTableAdapter.ClearBeforeFill = True
        '
        'Fees
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1942, 1102)
        Me.Controls.Add(Me.FeesDGV)
        Me.Controls.Add(Me.StuIDCb)
        Me.Controls.Add(Me.PayBtn)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.SNameTb)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.AmountTb)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.PeriodDTP)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Fees"
        Me.Text = "Fees"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.FeesDGV, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CollageMNGDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PaymentTblBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents SNameTb As System.Windows.Forms.TextBox
    Friend WithEvents PayBtn As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents PeriodDTP As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents AmountTb As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents FeesDGV As System.Windows.Forms.DataGridView
    Friend WithEvents StuIDCb As System.Windows.Forms.ComboBox
    Friend WithEvents CollageMNGDataSet As CollageMNGDataSet
    Friend WithEvents PaymentTblBindingSource As BindingSource
    Friend WithEvents PaymentTblTableAdapter As CollageMNGDataSetTableAdapters.PaymentTblTableAdapter
End Class
