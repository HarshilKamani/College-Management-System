﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Student
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Student))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.StuFeesTb = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.StuGenderCb = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.StuDobDTP = New System.Windows.Forms.DateTimePicker()
        Me.StuPhoneTb = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.StuNameTb = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.StudentDGV = New System.Windows.Forms.DataGridView()
        Me.StuDeptCb = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.StuAddTb = New System.Windows.Forms.TextBox()
        Me.Addlbl = New System.Windows.Forms.Label()
        Me.StuCityTb = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.ResetBtn = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.DeleteBtn = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.EditBtn = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.SaveBtn = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.CollageMNGDataSet = New COLLAGE.CollageMNGDataSet()
        Me.StudentTblBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StudentTblTableAdapter = New COLLAGE.CollageMNGDataSetTableAdapters.StudentTblTableAdapter()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        CType(Me.StudentDGV, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CollageMNGDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentTblBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Navy
        Me.Panel1.Controls.Add(Me.Button7)
        Me.Panel1.Controls.Add(Me.Button6)
        Me.Panel1.Controls.Add(Me.Button5)
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(344, 1102)
        Me.Panel1.TabIndex = 0
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.Navy
        Me.Button7.BackgroundImage = Global.COLLAGE.My.Resources.Resources._1035688
        Me.Button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button7.FlatAppearance.BorderSize = 0
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.Location = New System.Drawing.Point(66, 780)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(214, 113)
        Me.Button7.TabIndex = 45
        Me.Button7.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Navy
        Me.Button6.BackgroundImage = Global.COLLAGE.My.Resources.Resources._3141981
        Me.Button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button6.FlatAppearance.BorderSize = 0
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Location = New System.Drawing.Point(66, 577)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(214, 113)
        Me.Button6.TabIndex = 44
        Me.Button6.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.Navy
        Me.Button5.BackgroundImage = Global.COLLAGE.My.Resources.Resources.google_classroom
        Me.Button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button5.FlatAppearance.BorderSize = 0
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Location = New System.Drawing.Point(60, 370)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(214, 113)
        Me.Button5.TabIndex = 43
        Me.Button5.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Navy
        Me.Button4.BackgroundImage = Global.COLLAGE.My.Resources.Resources._2133094
        Me.Button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button4.FlatAppearance.BorderSize = 0
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Location = New System.Drawing.Point(60, 170)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(214, 113)
        Me.Button4.TabIndex = 42
        Me.Button4.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackgroundImage = Global.COLLAGE.My.Resources.Resources._152535
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button3.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace
        Me.Button3.FlatAppearance.BorderSize = 0
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Location = New System.Drawing.Point(89, 975)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(191, 62)
        Me.Button3.TabIndex = 38
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Navy
        Me.Label16.Font = New System.Drawing.Font("Century Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(142, 694)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(82, 37)
        Me.Label16.TabIndex = 20
        Me.Label16.Text = "Fees"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Navy
        Me.Label15.Font = New System.Drawing.Font("Century Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(88, 896)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(179, 37)
        Me.Label15.TabIndex = 19
        Me.Label15.Text = "Dashboard"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Navy
        Me.Label14.Font = New System.Drawing.Font("Century Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(76, 482)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(192, 37)
        Me.Label14.TabIndex = 18
        Me.Label14.Text = "Department"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Navy
        Me.Label13.Font = New System.Drawing.Font("Century Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(101, 285)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(146, 37)
        Me.Label13.TabIndex = 17
        Me.Label13.Text = "Teachers"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.SlateBlue
        Me.Panel2.Controls.Add(Me.PictureBox1)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(343, 141)
        Me.Panel2.TabIndex = 0
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.COLLAGE.My.Resources.Resources._4345672
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(125, 138)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 16
        Me.PictureBox1.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.SlateBlue
        Me.Label6.Font = New System.Drawing.Font("Magneto", 19.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Gold
        Me.Label6.Location = New System.Drawing.Point(122, 25)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(201, 82)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "    HK" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Univercity" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'StuFeesTb
        '
        Me.StuFeesTb.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentTblBindingSource, "StuDept", True))
        Me.StuFeesTb.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StuFeesTb.Location = New System.Drawing.Point(445, 344)
        Me.StuFeesTb.Name = "StuFeesTb"
        Me.StuFeesTb.Size = New System.Drawing.Size(305, 36)
        Me.StuFeesTb.TabIndex = 14
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Indigo
        Me.Label2.Location = New System.Drawing.Point(439, 289)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 34)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Fees"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.White
        Me.Panel4.Controls.Add(Me.Button8)
        Me.Panel4.Controls.Add(Me.Label1)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(344, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1598, 141)
        Me.Panel4.TabIndex = 15
        '
        'Button8
        '
        Me.Button8.BackgroundImage = Global.COLLAGE.My.Resources.Resources._1193
        Me.Button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button8.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace
        Me.Button8.FlatAppearance.BorderSize = 0
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Location = New System.Drawing.Point(1609, 3)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(53, 52)
        Me.Button8.TabIndex = 86
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 28.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Indigo
        Me.Label1.Location = New System.Drawing.Point(118, 68)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(220, 58)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Students"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Indigo
        Me.Label3.Location = New System.Drawing.Point(858, 166)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(119, 34)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "Gender"
        '
        'StuGenderCb
        '
        Me.StuGenderCb.DataBindings.Add(New System.Windows.Forms.Binding("SelectedItem", Me.StudentTblBindingSource, "StuGender", True))
        Me.StuGenderCb.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StuGenderCb.FormattingEnabled = True
        Me.StuGenderCb.Items.AddRange(New Object() {"MALE", "FEMALE"})
        Me.StuGenderCb.Location = New System.Drawing.Point(864, 220)
        Me.StuGenderCb.Name = "StuGenderCb"
        Me.StuGenderCb.Size = New System.Drawing.Size(266, 35)
        Me.StuGenderCb.TabIndex = 17
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Indigo
        Me.Label4.Location = New System.Drawing.Point(1216, 166)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 34)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "DOB"
        '
        'StuDobDTP
        '
        Me.StuDobDTP.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.StudentTblBindingSource, "StuDob", True))
        Me.StuDobDTP.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StuDobDTP.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.StuDobDTP.Location = New System.Drawing.Point(1222, 216)
        Me.StuDobDTP.Name = "StuDobDTP"
        Me.StuDobDTP.Size = New System.Drawing.Size(305, 36)
        Me.StuDobDTP.TabIndex = 19
        '
        'StuPhoneTb
        '
        Me.StuPhoneTb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.StuPhoneTb.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentTblBindingSource, "StuPhone", True))
        Me.StuPhoneTb.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StuPhoneTb.Location = New System.Drawing.Point(1625, 344)
        Me.StuPhoneTb.Name = "StuPhoneTb"
        Me.StuPhoneTb.Size = New System.Drawing.Size(305, 36)
        Me.StuPhoneTb.TabIndex = 21
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Indigo
        Me.Label5.Location = New System.Drawing.Point(1619, 289)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(152, 34)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "Phone no."
        '
        'StuNameTb
        '
        Me.StuNameTb.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentTblBindingSource, "StuName", True))
        Me.StuNameTb.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StuNameTb.Location = New System.Drawing.Point(445, 215)
        Me.StuNameTb.Name = "StuNameTb"
        Me.StuNameTb.Size = New System.Drawing.Size(305, 36)
        Me.StuNameTb.TabIndex = 23
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Indigo
        Me.Label7.Location = New System.Drawing.Point(439, 166)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(99, 34)
        Me.Label7.TabIndex = 22
        Me.Label7.Text = "Name"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label8.Location = New System.Drawing.Point(1093, 740)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(0, 34)
        Me.Label8.TabIndex = 24
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.SystemColors.Control
        Me.Label12.Font = New System.Drawing.Font("Century Gothic", 22.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Indigo
        Me.Label12.Location = New System.Drawing.Point(1036, 534)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(246, 45)
        Me.Label12.TabIndex = 17
        Me.Label12.Text = "Students List"
        '
        'StudentDGV
        '
        Me.StudentDGV.AllowUserToAddRows = False
        Me.StudentDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.StudentDGV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.StudentDGV.BackgroundColor = System.Drawing.Color.White
        Me.StudentDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        Me.StudentDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.Navy
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Navy
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Lavender
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.StudentDGV.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.StudentDGV.ColumnHeadersHeight = 28
        Me.StudentDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.StudentDGV.Cursor = System.Windows.Forms.Cursors.Default
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.Gold
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.DarkBlue
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.StudentDGV.DefaultCellStyle = DataGridViewCellStyle8
        Me.StudentDGV.EnableHeadersVisualStyles = False
        Me.StudentDGV.GridColor = System.Drawing.Color.White
        Me.StudentDGV.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.StudentDGV.Location = New System.Drawing.Point(401, 624)
        Me.StudentDGV.Name = "StudentDGV"
        Me.StudentDGV.ReadOnly = True
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Century Gothic", 14.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.Gold
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.DarkBlue
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.StudentDGV.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.StudentDGV.RowHeadersWidth = 51
        Me.StudentDGV.RowTemplate.Height = 24
        Me.StudentDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.StudentDGV.Size = New System.Drawing.Size(1621, 413)
        Me.StudentDGV.TabIndex = 85
        '
        'StuDeptCb
        '
        Me.StuDeptCb.DataBindings.Add(New System.Windows.Forms.Binding("SelectedItem", Me.StudentTblBindingSource, "StuDept", True))
        Me.StuDeptCb.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StuDeptCb.FormattingEnabled = True
        Me.StuDeptCb.Items.AddRange(New Object() {""})
        Me.StuDeptCb.Location = New System.Drawing.Point(1625, 217)
        Me.StuDeptCb.Name = "StuDeptCb"
        Me.StuDeptCb.Size = New System.Drawing.Size(305, 35)
        Me.StuDeptCb.TabIndex = 87
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.SystemColors.Control
        Me.Label9.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Indigo
        Me.Label9.Location = New System.Drawing.Point(1619, 163)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(181, 34)
        Me.Label9.TabIndex = 86
        Me.Label9.Text = "Department"
        '
        'StuAddTb
        '
        Me.StuAddTb.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentTblBindingSource, "StuAdd", True))
        Me.StuAddTb.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StuAddTb.Location = New System.Drawing.Point(864, 343)
        Me.StuAddTb.Name = "StuAddTb"
        Me.StuAddTb.Size = New System.Drawing.Size(266, 36)
        Me.StuAddTb.TabIndex = 89
        '
        'Addlbl
        '
        Me.Addlbl.AutoSize = True
        Me.Addlbl.BackColor = System.Drawing.SystemColors.Control
        Me.Addlbl.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Addlbl.ForeColor = System.Drawing.Color.Indigo
        Me.Addlbl.Location = New System.Drawing.Point(858, 288)
        Me.Addlbl.Name = "Addlbl"
        Me.Addlbl.Size = New System.Drawing.Size(122, 34)
        Me.Addlbl.TabIndex = 88
        Me.Addlbl.Text = "Address"
        '
        'StuCityTb
        '
        Me.StuCityTb.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentTblBindingSource, "StuCity", True))
        Me.StuCityTb.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StuCityTb.Location = New System.Drawing.Point(1222, 343)
        Me.StuCityTb.Name = "StuCityTb"
        Me.StuCityTb.Size = New System.Drawing.Size(305, 36)
        Me.StuCityTb.TabIndex = 91
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.SystemColors.Control
        Me.Label11.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Indigo
        Me.Label11.Location = New System.Drawing.Point(1216, 288)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(70, 34)
        Me.Label11.TabIndex = 90
        Me.Label11.Text = "City"
        '
        'ResetBtn
        '
        Me.ResetBtn.ActiveBorderThickness = 1
        Me.ResetBtn.ActiveCornerRadius = 20
        Me.ResetBtn.ActiveFillColor = System.Drawing.Color.SeaGreen
        Me.ResetBtn.ActiveForecolor = System.Drawing.Color.White
        Me.ResetBtn.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.ResetBtn.BackColor = System.Drawing.SystemColors.Control
        Me.ResetBtn.BackgroundImage = CType(resources.GetObject("ResetBtn.BackgroundImage"), System.Drawing.Image)
        Me.ResetBtn.ButtonText = "Reset"
        Me.ResetBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ResetBtn.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ResetBtn.ForeColor = System.Drawing.Color.SeaGreen
        Me.ResetBtn.IdleBorderThickness = 1
        Me.ResetBtn.IdleCornerRadius = 20
        Me.ResetBtn.IdleFillColor = System.Drawing.Color.Gold
        Me.ResetBtn.IdleForecolor = System.Drawing.Color.Black
        Me.ResetBtn.IdleLineColor = System.Drawing.Color.Gold
        Me.ResetBtn.Location = New System.Drawing.Point(1575, 450)
        Me.ResetBtn.Margin = New System.Windows.Forms.Padding(7, 7, 7, 7)
        Me.ResetBtn.Name = "ResetBtn"
        Me.ResetBtn.Size = New System.Drawing.Size(276, 52)
        Me.ResetBtn.TabIndex = 35
        Me.ResetBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'DeleteBtn
        '
        Me.DeleteBtn.ActiveBorderThickness = 1
        Me.DeleteBtn.ActiveCornerRadius = 20
        Me.DeleteBtn.ActiveFillColor = System.Drawing.Color.SeaGreen
        Me.DeleteBtn.ActiveForecolor = System.Drawing.Color.White
        Me.DeleteBtn.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.DeleteBtn.BackColor = System.Drawing.SystemColors.Control
        Me.DeleteBtn.BackgroundImage = CType(resources.GetObject("DeleteBtn.BackgroundImage"), System.Drawing.Image)
        Me.DeleteBtn.ButtonText = "Delete"
        Me.DeleteBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.DeleteBtn.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeleteBtn.ForeColor = System.Drawing.Color.SeaGreen
        Me.DeleteBtn.IdleBorderThickness = 1
        Me.DeleteBtn.IdleCornerRadius = 20
        Me.DeleteBtn.IdleFillColor = System.Drawing.Color.Gold
        Me.DeleteBtn.IdleForecolor = System.Drawing.Color.Black
        Me.DeleteBtn.IdleLineColor = System.Drawing.Color.Gold
        Me.DeleteBtn.Location = New System.Drawing.Point(881, 453)
        Me.DeleteBtn.Margin = New System.Windows.Forms.Padding(7, 7, 7, 7)
        Me.DeleteBtn.Name = "DeleteBtn"
        Me.DeleteBtn.Size = New System.Drawing.Size(276, 52)
        Me.DeleteBtn.TabIndex = 34
        Me.DeleteBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'EditBtn
        '
        Me.EditBtn.ActiveBorderThickness = 1
        Me.EditBtn.ActiveCornerRadius = 20
        Me.EditBtn.ActiveFillColor = System.Drawing.Color.SeaGreen
        Me.EditBtn.ActiveForecolor = System.Drawing.Color.White
        Me.EditBtn.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.EditBtn.BackColor = System.Drawing.SystemColors.Control
        Me.EditBtn.BackgroundImage = CType(resources.GetObject("EditBtn.BackgroundImage"), System.Drawing.Image)
        Me.EditBtn.ButtonText = "Edit"
        Me.EditBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.EditBtn.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EditBtn.ForeColor = System.Drawing.Color.SeaGreen
        Me.EditBtn.IdleBorderThickness = 1
        Me.EditBtn.IdleCornerRadius = 20
        Me.EditBtn.IdleFillColor = System.Drawing.Color.Gold
        Me.EditBtn.IdleForecolor = System.Drawing.Color.Black
        Me.EditBtn.IdleLineColor = System.Drawing.Color.Gold
        Me.EditBtn.Location = New System.Drawing.Point(1231, 450)
        Me.EditBtn.Margin = New System.Windows.Forms.Padding(7, 7, 7, 7)
        Me.EditBtn.Name = "EditBtn"
        Me.EditBtn.Size = New System.Drawing.Size(276, 52)
        Me.EditBtn.TabIndex = 33
        Me.EditBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SaveBtn
        '
        Me.SaveBtn.ActiveBorderThickness = 1
        Me.SaveBtn.ActiveCornerRadius = 20
        Me.SaveBtn.ActiveFillColor = System.Drawing.Color.SeaGreen
        Me.SaveBtn.ActiveForecolor = System.Drawing.Color.White
        Me.SaveBtn.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.SaveBtn.BackColor = System.Drawing.SystemColors.Control
        Me.SaveBtn.BackgroundImage = CType(resources.GetObject("SaveBtn.BackgroundImage"), System.Drawing.Image)
        Me.SaveBtn.ButtonText = "Save"
        Me.SaveBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.SaveBtn.Font = New System.Drawing.Font("Century Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SaveBtn.ForeColor = System.Drawing.Color.SeaGreen
        Me.SaveBtn.IdleBorderThickness = 1
        Me.SaveBtn.IdleCornerRadius = 20
        Me.SaveBtn.IdleFillColor = System.Drawing.Color.Gold
        Me.SaveBtn.IdleForecolor = System.Drawing.Color.Black
        Me.SaveBtn.IdleLineColor = System.Drawing.Color.Gold
        Me.SaveBtn.Location = New System.Drawing.Point(531, 450)
        Me.SaveBtn.Margin = New System.Windows.Forms.Padding(7, 7, 7, 7)
        Me.SaveBtn.Name = "SaveBtn"
        Me.SaveBtn.Size = New System.Drawing.Size(276, 52)
        Me.SaveBtn.TabIndex = 32
        Me.SaveBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CollageMNGDataSet
        '
        Me.CollageMNGDataSet.DataSetName = "CollageMNGDataSet"
        Me.CollageMNGDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'StudentTblBindingSource
        '
        Me.StudentTblBindingSource.DataMember = "StudentTbl"
        Me.StudentTblBindingSource.DataSource = Me.CollageMNGDataSet
        '
        'StudentTblTableAdapter
        '
        Me.StudentTblTableAdapter.ClearBeforeFill = True
        '
        'Student
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1942, 1102)
        Me.Controls.Add(Me.StuCityTb)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.StuAddTb)
        Me.Controls.Add(Me.Addlbl)
        Me.Controls.Add(Me.StuDeptCb)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.StudentDGV)
        Me.Controls.Add(Me.ResetBtn)
        Me.Controls.Add(Me.DeleteBtn)
        Me.Controls.Add(Me.EditBtn)
        Me.Controls.Add(Me.SaveBtn)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.StuNameTb)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.StuPhoneTb)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.StuDobDTP)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.StuGenderCb)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.StuFeesTb)
        Me.Controls.Add(Me.Label2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Student"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Students"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.StudentDGV, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CollageMNGDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentTblBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents StuFeesTb As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents StuGenderCb As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents StuDobDTP As System.Windows.Forms.DateTimePicker
    Friend WithEvents StuPhoneTb As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents StuNameTb As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents SaveBtn As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents EditBtn As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents DeleteBtn As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents ResetBtn As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents StudentDGV As System.Windows.Forms.DataGridView
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents StuDeptCb As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents StuAddTb As System.Windows.Forms.TextBox
    Friend WithEvents Addlbl As System.Windows.Forms.Label
    Friend WithEvents StuCityTb As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents CollageMNGDataSet As CollageMNGDataSet
    Friend WithEvents StudentTblBindingSource As BindingSource
    Friend WithEvents StudentTblTableAdapter As CollageMNGDataSetTableAdapters.StudentTblTableAdapter
End Class
