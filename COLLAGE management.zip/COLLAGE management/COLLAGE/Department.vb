﻿Imports System.Data
Imports System.Data.OleDb

Public Class Department
    Dim con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\a\Documents\COLLAGE management\COLLAGE\CollageMNG.accdb")
    Dim Keys As Integer
    Dim query As Object

    Private Sub Display()
        con.open()
        Dim query = "Select * from DepartmentTbl"
        Dim adepter As OleDbDataAdapter
        Dim cmd = New OleDbCommand(query, con)
        adepter = New OleDbDataAdapter(cmd)
        Dim builder = New OleDbCommandBuilder(adepter)
        Dim ds As DataSet
        ds = New DataSet
        adepter.Fill(ds)
        DepartmentDGV.DataSource = ds.Tables(0)
        con.close()
    End Sub

    Private Sub Savebtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Savebtn.Click
        If DepNameTb.Text = "" Or DepDescriTb.Text = "" Or DepDuraTb.Text = "" Then
            MsgBox("missing information")
        Else
            Try
                con.Open()
                Dim query = ("insert into DepartmentTbl(DepName,DepDescri,Depdura) values ('" & DepNameTb.Text & "','" & DepDescriTb.Text & "','" & DepDuraTb.Text & "')")
                Dim cmd As OleDbCommand
                cmd = New OleDbCommand(query, con)
                cmd.ExecuteNonQuery()
                MsgBox("Department Saved Successfully")
                con.Close()
                Display()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Department_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CollageMNGDataSet.DepartmentTbl' table. You can move, or remove it, as needed.
        Me.DepartmentTblTableAdapter.Fill(Me.CollageMNGDataSet.DepartmentTbl)
        Display()
    End Sub

    Private Sub Reset()
        DepNameTb.Text = ""
        DepDescriTb.Text = ""
        DepDuraTb.Text = ""
    End Sub

    Private Sub Resetbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Resetbtn.Click
        Reset()
    End Sub

    Private Sub DeleteBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteBtn.Click
        If key = 0 Then
            MsgBox("Select The Department")
        Else
            Try
                con.open()
                Dim query = "delete from DepartmentTbl where DepId=" & key & ""
                Dim cmd As OleDbCommand
                cmd = New OleDbCommand(query, con)
                cmd.ExecuteNonQuery()
                MsgBox("department Deleted successfull")
                con.close()
                Display()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub
    Dim key = 0
    Private Sub DepartmentDGV_CellMouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DepartmentDGV.CellMouseClick
        Dim row As DataGridViewRow = DepartmentDGV.Rows(e.RowIndex)
        DepNameTb.Text = row.Cells(1).Value.ToString
        DepDescriTb.Text = row.Cells(2).Value.ToString
        DepDuraTb.Text = row.Cells(3).Value.ToString
        If DepNameTb.Text = "" Then
            key = 0
        Else
            key = Convert.ToInt32(row.Cells(0).Value.ToString)
        End If
    End Sub

    Private Sub EditBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditBtn.Click
        If DepNameTb.Text = "" Or DepDescriTb.Text = "" Or DepDuraTb.Text = "" Then
            MsgBox("missing information")
        Else
            Try
                con.Open()
                Dim query = "update DepartmentTbl set DepName='" & DepNameTb.Text & "',DepDescri='" & DepDescriTb.Text & "',DepDura='" & DepDuraTb.Text & "' where DepId=" & key & " "
                Dim cmd As OleDbCommand
                cmd = New OleDbCommand(query, con)
                cmd.ExecuteNonQuery()
                MsgBox("Department Update Successfully")
                con.Close()
                Display()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

   
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim obj = New Login()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim obj = New Dashboard()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim obj = New Fees()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Dim obj = New Student()
        obj.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim obj = New Teacher()
        obj.Show()
        Me.Hide()
    End Sub
End Class
